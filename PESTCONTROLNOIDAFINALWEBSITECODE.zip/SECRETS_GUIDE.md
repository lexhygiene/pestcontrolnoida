# Project Recovery & Secrets Guide

**IMPORTANT:** For security reasons, this zip file does NOT contain your `.env` files because they contain private passwords (SMTP, API Keys) that should NEVER be published to GitHub.

## How to Restore Your Environment

When you download this code again in the future, you will need to recreate two files:

### 1. Root `.env.local`
Create a file named `.env.local` in the main folder and add these lines (replace with your actual keys):

```
VITE_RECAPTCHA_SITE_KEY=your_recaptcha_site_key_here
VITE_ADMIN_API_KEY=your_secure_admin_password_here
```

### 2. Server `.env`
Create a file named `.env` inside the `server/` folder and add these lines:

```
PORT=5000
SMTP_HOST=mail.pestcontrolnoida.in
SMTP_PORT=465
SMTP_USER=info@pestcontrolnoida.in
SMTP_PASS=your_email_password_here
ADMIN_API_KEY=your_secure_admin_password_here
RECAPTCHA_SECRET_KEY=your_google_recaptcha_secret_key
```

## How to Run the Project
1.  Install dependencies: `npm install`
2.  Go to server folder: `cd server`
3.  Install server dependencies: `npm install`
4.  Go back to root: `cd ..`
5.  Start everything: `npm run dev` (frontend) and `node server/index.js` (backend)
